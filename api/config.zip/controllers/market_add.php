<?php

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: PUT, GET, POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Methods, Authorization, X-Requested-With');

include_once '../config/Database.php';
include_once '../models/all.php';
include_once '../models/core.php';

//Instantiate DB & connect
// $database = new Database();
// $db = $database->connect();
$db = getDB();

$user = new Users($db);

//Get raw posted data
//$data = json_decode(file_get_contents("php://input"));

//sponsor generated id
//$user->sponsorLink = isset($_GET['sponsor']) ? $_GET['sponsor'] : die();
$result = array();

$user->marketname = htmlspecialchars(trim($_POST['marketname']));
$user->marketchair = htmlspecialchars(trim($_POST['marketchair']));
$user->marketstate = htmlspecialchars(trim($_POST['marketstate']));
$user->marketaddress = htmlspecialchars(trim($_POST['marketaddress']));
$user->marketdescrip = htmlspecialchars(trim($_POST['marketdescrip']));
$user->created_by = htmlspecialchars(trim($_POST['created_by']));
$user->marketstatus = 'Active';
$user->marketimgid = mt_rand(100000, 999999);

$user->file_name = $file_size = $file_tmp = $file_type = "";

$user->file_name = @$_FILES['marketimg']['name'];
$user->file_size = @$_FILES['marketimg']['size'];
$user->file_tmp = @$_FILES['marketimg']['tmp_name'];
$user->file_type = @$_FILES['marketimg']['type'];

$user->file_name  = $user->marketimgid."-".$user->file_name;

$user->marketimg = $user->file_name;

//is_dir( "../../seller/marketImage/".$user->marketname )

if($user->isMarketExist()) {
   	header('Location: ../../admin/market_setting.php?result=Market already already exist!');
	return false;
}

if(is_uploaded_file($user->file_tmp)){
    if($file_size > 1097152 ){
    	header('Location: ../../admin/market_setting.php?result=File must not exceed 1MB.');
        return true;
    }else{
    	if($user->create_market()){
			mkdir( "../../seller/marketImage/".$user->marketname );
				$targetPath = "../../seller/marketImage/".$user->marketname.'/'.$user->file_name;
				if(move_uploaded_file($user->file_tmp, $targetPath)) {
					header('Location: ../../admin/market_setting.php?result=Market added!');
					return true;
				}
		}else{
			header("location: ../../admin/market_setting.php?result=Fail to create market");
			return false;
		}
    }
	
}else{
	header('Location: ../../admin/market_setting.php?result=Please upload market image!');
	return false;
}

?>