<?php
class Users{
    //DB Stuff
    private $conn;
    private $table = 'users';

    public $role;
    public $userid;
    public $username;
    public $password;
    public $email;
    public $fname;
    public $lname;
    public $phone;
    public $state;
    public $address;
    public $confCode;
    public $status;
    public $datereg;

    public $marketid;
    public $marketname;
    public $marketchair;
    public $marketstate;
    public $marketaddress;
    public $marketdescrip;
    public $marketimg;
    public $marketstatus;
    public $created_by;

    public $file_name;
    public $file_tmp;
    public $file_type;
    public $file_size;

    public $catid;
    public $catname;
    public $catdescription;
    public $created_at;
    public $t_product;

    public $plan;
    public $lastlogin;

    public $title;
    public $body;
    public $generatedlink;
    public $butt;

    public function __construct($db){
        $this->conn = $db;
    }

    public function getUser(){
        return $this->user;
    }

    //create_user
    public function create_user(){
        $this->userid = mt_rand(100000, 999999);
        $this->status = 0;
        $this->confCode = 'Starter';

        if($this->isUsernameExit()) {
            echo 'username';
            return false;
        }

        if($this->isEmailExit()){
            echo 'email';
            return false;
        }

        $query = "INSERT INTO users (userid,username,email,password,fname,lname,phone,state,address,status,role) VALUES (:userid,:username,:email,:password,:fname,:lname,:phone,:state,:address,:status,:role)";

        $stmt = $this->conn->prepare($query);

        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->username = htmlspecialchars(strip_tags($this->username));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = htmlspecialchars(strip_tags(password_hash($this->password, PASSWORD_BCRYPT, array("cost" => 12))));
        $this->fname = htmlspecialchars(strip_tags($this->fname));
        $this->lname = htmlspecialchars(strip_tags($this->lname));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->state = htmlspecialchars(strip_tags($this->state));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->status = htmlspecialchars(strip_tags($this->status));
        // $this->confCode = htmlspecialchars(strip_tags($this->confCode));
        $this->role = htmlspecialchars(strip_tags($this->role));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('username', $this->username);
        $stmt->bindValue('email', $this->email);
        $stmt->bindValue('password', $this->password);
        $stmt->bindValue('fname', $this->fname);
        $stmt->bindValue('lname', $this->lname);
        $stmt->bindValue('phone', $this->phone);
        $stmt->bindValue('state', $this->state);
        $stmt->bindValue('address', $this->address);
        $stmt->bindValue('status', $this->status);
        // $stmt->bindValue('confCode', $this->confCode);
        $stmt->bindValue('role', $this->role);

        if($stmt->execute()){
            $this->userid = $this->userid;
            $this->title = "New Seller Registration";
            $this->body = "This Seller Just Registered". ' - ' .$this->username;
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();

            if($this->role == 'Seller'){
                $this->account_type = 'Starter';
                $this->durate = '';
                $this->start_date = '';
                $this->end_date = '';
                $this->userAcctType();
            }
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;
    }

    public function updatePersonalInfo(){
                
        $query = "UPDATE users SET fname=:fname, lname=:lname, phone=:phone, address=:address, state=:state WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->fname = htmlspecialchars(strip_tags($this->fname));
        $this->lname = htmlspecialchars(strip_tags($this->lname));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->state = htmlspecialchars(strip_tags($this->state));
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('fname', $this->fname);
        $stmt->bindValue('lname', $this->lname);
        $stmt->bindValue('phone', $this->phone);
        $stmt->bindValue('address', $this->address);
        $stmt->bindValue('state', $this->state);
        $stmt->bindValue('userid', $this->userid);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function createBusinessInfo(){

        if($this->checkBizInfo($this->userid)){
            echo 'exist';
            return false;
        }

        $this->cardsettings = 1;

        $query = "INSERT INTO business (userid,bizname,bizphone,bizemail,bizstate,bizmarket,bizaddress,bizwebsite,bizregdate,cardsettings,status) VALUES (:userid,:bizname,:bizphone,:bizemail,:bizstate,:bizmarket,:bizaddress,:bizwebsite,:bizregdate,:cardsettings,:status)";

        $stmt = $this->conn->prepare($query);

        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->bizname = htmlspecialchars(strip_tags($this->bizname));
        $this->bizphone = htmlspecialchars(strip_tags($this->bizphone));
        $this->bizemail = htmlspecialchars(strip_tags($this->bizemail));
        $this->bizstate = json_encode($this->bizstate);
        $this->bizmarket = json_encode($this->bizmarket);
        $this->bizaddress = htmlspecialchars(strip_tags($this->bizaddress));
        $this->bizwebsite = htmlspecialchars(strip_tags($this->bizwebsite));
        $this->bizregdate = htmlspecialchars(strip_tags($this->bizregdate));
        $this->cardsettings = htmlspecialchars(strip_tags($this->cardsettings));
        $this->status = htmlspecialchars(strip_tags($this->status));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('bizname', $this->bizname);
        $stmt->bindValue('bizphone', $this->bizphone);
        $stmt->bindValue('bizemail', $this->bizemail);
        $stmt->bindValue('bizstate', $this->bizstate);
        $stmt->bindValue('bizmarket', $this->bizmarket);
        $stmt->bindValue('bizaddress', $this->bizaddress);
        $stmt->bindValue('bizwebsite', $this->bizwebsite);
        $stmt->bindValue('bizregdate', $this->bizregdate);
        $stmt->bindValue('cardsettings', $this->cardsettings);
        $stmt->bindValue('status', $this->status);

        if($stmt->execute()){
            $this->userid = $this->userid;
            $this->title = "New Business Information Created";
            $this->body = "A new business information has been created!";
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    /* business Details check */
    public function checkBizInfo($userid){
        $stmtbiz = $this->conn->prepare("SELECT * FROM business WHERE userid=:userid AND status=:status");
        $stmtbiz->bindValue("userid", $this->userid);
        $stmtbiz->bindValue("status", $this->status);
        $stmtbiz->execute();
        if($stmtbiz->rowCount() > 0){
            return true;
        }
    }

    /* business Details */
    public function bizDetails($userid){
        // $this->status = 'Updated';
        $stmtbiz = $this->conn->prepare("SELECT * FROM business WHERE userid=:userid AND status=:status OR status=:status2");
        $stmtbiz->bindValue("userid", $userid);
        $stmtbiz->bindValue("status", 'Updated');        
        $stmtbiz->bindValue("status2", 'Updateable');        
        $stmtbiz->execute();
        if($stmtbiz->rowCount() > 0){
            $data = $stmtbiz->fetch(PDO::FETCH_OBJ); //User data
            return $data;
        }else{
            return 'empty';
        }
    }

    public function updatereturnpolicy(){
                
        $query = "UPDATE business SET returnpolicy=:return_policy WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->return_policy = htmlentities($this->return_policy);
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('return_policy', $this->return_policy);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function updatedisclaimer(){
        
        $query = "UPDATE business SET disclaimer=:sellerdisclaimer WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->sellerdisclaimer = htmlentities($this->sellerdisclaimer);
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('sellerdisclaimer', $this->sellerdisclaimer);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function updatetimedelivery(){
        
        $query = "UPDATE business SET timedelivery=:time_delivery WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->time_delivery = htmlentities($this->time_delivery);
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('time_delivery', $this->time_delivery);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function updatevideolink(){
        
        $query = "UPDATE business SET videolink=:videolink WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->videolink = htmlentities($this->videolink);
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('videolink', $this->videolink);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function addstoreimage(){
        
        $query = "UPDATE business SET storeimage=:storeimage WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->storeimage = $this->storeimage;
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('storeimage', $this->storeimage);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    //check if give username exist in the database
    public function userLogin($username, $password){
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? limit 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (password_verify($password, $user['password'])) {
            if ($user['status'] == 1) {
                $this->user = $user;
                session_regenerate_id();
                $_SESSION['userid'] = $user['userid'];
                $_SESSION['role'] = $user['role'];
                $this->updateLastLogin();

                $this->userid = $user['userid'];
                $this->title = $user['username']. ' ' . 'just logged in!';
                $this->body = "A Seller Logged in at ". ' - ' .date('Y-m-d H:i:s');
                $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
                $this->notifications();

                echo $user['role'];
                return true;
            } else {
                echo 'Inactive';
                return false;
            }
        } else {
           echo 'Invalid';
            return false;
        }
    }

    public function updateLastLogin(){

        $this->lastlogin = date('Y-m-d H:i:s');

        $sqli = "UPDATE users SET lastlogin=:lastlogin WHERE userid=:userid";
        $stmti = $this->conn->prepare($sqli);
        $stmti->bindParam(':lastlogin', $this->lastlogin);
        $stmti->bindParam(':userid', $_SESSION['userid']);
        if($stmti->execute()){
            return true;
        }
    }

    public function create_market(){
                
            $query = "INSERT INTO market (marketid,marketname,marketchairman,marketstate,marketaddress,marketdescription,marketimg,marketstatus,created_by) 
                VALUES (:marketid,:marketname,:marketchair,:marketstate,:marketaddress,:marketdescrip,:marketimg,:marketstatus,:created_by)";

            $stmt = $this->conn->prepare($query);

            $this->marketid = htmlspecialchars(strip_tags($this->marketid));
            $this->marketname = htmlspecialchars(strip_tags($this->marketname));
            $this->marketchair = htmlspecialchars(strip_tags($this->marketchair));
            $this->marketstate = htmlspecialchars(strip_tags($this->marketstate));
            $this->marketaddress = htmlspecialchars(strip_tags($this->marketaddress));
            $this->marketdescrip = htmlspecialchars(strip_tags($this->marketdescrip));
            $this->marketimg = htmlspecialchars(strip_tags($this->marketimg));
            $this->marketstatus = htmlspecialchars(strip_tags($this->marketstatus));
            $this->created_by = htmlspecialchars(strip_tags($this->created_by));

            $stmt->bindValue('marketid', $this->marketid);
            $stmt->bindValue('marketname', $this->marketname);
            $stmt->bindValue('marketchair', $this->marketchair);
            $stmt->bindValue('marketstate', $this->marketstate);
            $stmt->bindValue('marketaddress', $this->marketaddress);
            $stmt->bindValue('marketdescrip', $this->marketdescrip);
            $stmt->bindValue('marketimg', $this->marketimg);
            $stmt->bindValue('marketstatus', $this->marketstatus);
            $stmt->bindValue('created_by', $this->created_by);

            if($stmt->execute()){
                $this->userid = 'all';
                $this->title = 'New Market Created!';
                $this->body = 'A new market has been created by the Admin. Explore!';
                $this->generatedlink = "market_setting.php?marketid=".$this->marketid;
                $this->notifications();

                return true;
            }
            printf("Error: %s.\n", $stmt->error);
            return false;        
    }

    public function create_dispute(){
                
        $query = "INSERT INTO disputetbl (disputeid,senderid,againstid,subject,priority,details_priority,file_name,status) 
            VALUES (:disputeid,:senderid,:againstid,:subject,:priority,:details_priority,:file_name,:status)";

        $stmt = $this->conn->prepare($query);

        $this->disputeid = htmlspecialchars(strip_tags($this->disputeid));
        $this->senderid = htmlspecialchars(strip_tags($this->senderid));
        $this->againstid = htmlspecialchars(strip_tags($this->againstid));
        $this->subject = htmlspecialchars(strip_tags($this->subject));
        $this->priority = htmlspecialchars(strip_tags($this->priority));
        $this->details_priority = htmlspecialchars(strip_tags($this->details_priority));
        $this->file_name = htmlspecialchars(strip_tags($this->file_name));
        $this->status = htmlspecialchars(strip_tags($this->disputestatus));

        $stmt->bindValue('disputeid', $this->disputeid);
        $stmt->bindValue('senderid', $this->senderid);
        $stmt->bindValue('againstid', $this->againstid);
        $stmt->bindValue('subject', $this->subject);
        $stmt->bindValue('priority', $this->priority);
        $stmt->bindValue('details_priority', $this->details_priority);
        $stmt->bindValue('file_name', $this->file_name);
        $stmt->bindValue('status', $this->status);

        if($stmt->execute()){
            $this->userid = $this->senderid.', '.$this->againstid;
            $this->title = 'New Dispute Created!';
            $this->body = 'A new dispute has been created!';
            $this->generatedlink = "dispute_details.php?disputeid=".$this->disputeid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    //Get User dispute  List
    public function user_dispute_list($userid){
        $this->userid = $userid;
        $sql = 'SELECT * FROM disputetbl WHERE senderid='.$this->userid.' AND againstid= '.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            $cnt = $this->userDetails($row['senderid']);
            $cnt2 = $this->userDetails($row['againstid']);

            $this->timestamp = $row['created_at'];
            $this->splitTimeStamp = explode(" ",$this->timestamp);
            $this->date = $this->splitTimeStamp[0];
            $this->time = $this->splitTimeStamp[1];

            if($row['status'] == 'Pending'){
                $this->stat = '<span class="badge badge-pill badge-sm badge-warning">Pending</span>';
            }elseif($row['status'] == 'Resolved'){
                $this->stat = '<span class="badge badge-pill badge-sm badge-success">Resolved</span>';
            }elseif($row['status'] == 'Cancelled'){
                $this->stat = '<span class="badge badge-pill badge-sm badge-secondary">Cancelled</span>';
            }

            echo '<tr>
                    <td>
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left mr-3">
                                    <i class="fa fa-file fa-2x"></i>
                                </div>
                                <div class="widget-content-left">
                                    <div class="widget-heading">'.$row['subject'].'</div>
                                    <div class="widget-subheading">Filed against '. ucfirst($cnt2->username) .'</div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td class="text-left">'.$result = mb_substr($row['details_priority'], 0, 50).'</td>
                    <td>
                        '.$this->stat.'
                    </td>
                    <td>
                        <a class="btn btn-info btn-sm text-white" id="reply_dispute"><i class="fa fa-reply fa-w-20 opacity-4"></i></a>
                    </td>
                    <td class="text-right">
                        '.$this->date.'
                    </td>
                </tr>';
        }     
    }

    public function dispute_count($userid, $ss){
        $this->userid = $userid;
        $this->ss = ucfirst($ss);
        $sql = "SELECT count(*) FROM `disputetbl` WHERE senderid=:userid AND againstid=:userid AND status=:status"; 
        $stmt = $this->conn->prepare($sql);

        $stmt->bindValue('userid', $userid);
        $stmt->bindValue('status', $ss);
        if($stmt->execute()){
            $number_of_rows = $stmt->fetchColumn(); 
            echo $number_of_rows;
            return;
            // return;
        }


        // $result = $con->prepare($sql); 
        // $result->execute(); 
        // $number_of_rows = $result->fetchColumn(); 
    }

    public function userAcctType(){
                
            $query = "INSERT INTO account_info (userid,account_type,durate,start_date,end_date) VALUES (:userid,:account_type,:durate,:start_date,:end_date)";

            $stmt = $this->conn->prepare($query);

            $this->userid = htmlspecialchars(strip_tags($this->userid));
            $this->account_type = htmlspecialchars(strip_tags($this->account_type));
            $this->durate = htmlspecialchars(strip_tags($this->durate));
            $this->start_date = htmlspecialchars(strip_tags($this->start_date));
            $this->end_date = htmlspecialchars(strip_tags($this->end_date));

            $stmt->bindValue('userid', $this->userid);
            $stmt->bindValue('account_type', $this->account_type);
            $stmt->bindValue('durate', $this->durate);
            $stmt->bindValue('start_date', $this->start_date);
            $stmt->bindValue('end_date', $this->end_date);

            if($stmt->execute()){
                return true;
            }
            printf("Error: %s.\n", $stmt->error);
            return false;        
    }

    public function updateprofilepic(){


        if($this->isProPicExist()){
            $sqli = "UPDATE profilepic SET file_name=:file_name WHERE userid=:userid";
            $stmt = $this->conn->prepare($sqli);
            $this->userid = htmlspecialchars(strip_tags($this->userid));
            $this->file_name = htmlspecialchars(strip_tags($this->file_name));
            $stmt->bindValue('userid', $this->userid);
            $stmt->bindValue('file_name', $this->file_name);

            if($stmt->execute()){
                $this->userid = $this->userid;
                $this->title = 'New Profile Picture Update';
                $this->body = 'A user just update his/her profile picture!';
                $this->generatedlink = "user_details?userid=".$this->userid;
                $this->notifications();
                return true;
            }
            printf("Error: %s.\n", $stmt->error);
            return false;
        }

        $query = "INSERT INTO profilepic (userid,file_name,status) VALUES (:userid,:file_name,:status)";
        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->file_name = htmlspecialchars(strip_tags($this->file_name));
        $this->status = htmlspecialchars(strip_tags($this->status));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('file_name', $this->file_name);
        $stmt->bindValue('status', $this->status);

        if($stmt->execute()){
            $this->userid = $this->userid;
            $this->title = 'New Profile Picture Update';
            $this->body = 'A user just update his/her profile picture!';
            $this->generatedlink = "user_details?userid=".$this->userid;
            $this->notifications();
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;
    }

    public function readProfilePix($userid){
        $query = "SELECT * FROM profilepic WHERE userid = :userid";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam('userid', $userid);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        // return $row['file_name'];
        if($row['file_name'] == ''){
            echo '<img src="images/avatars/avatar.jpg" width="150" alt="Avatar 6">';
            return;
        }else{
            echo '<img src="profilepicture/'.$userid.'/'.$row['file_name'].'"width="100" height="100" class="rounded-circle" alt="Profile Picture">';
            return;
        }
    }

    public function readProfilePix2($userid){
        $query = "SELECT * FROM profilepic WHERE userid = :userid";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam('userid', $userid);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        // return $row['file_name'];
        if($row['file_name'] == ''){
            echo '<img src="images/avatars/avatar.jpg" width="50" height="50" alt="Avatar 6">';
            return;
        }else{
            echo '<img src="profilepicture/'.$userid.'/'.$row['file_name'].'"width="50" height="50" class="rounded-circle" alt="Profile Picture">';
            return;
        }
    }

    public function isProPicExist(){
        $query = "SELECT * FROM profilepic WHERE userid=:userid";
        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $stmt->bindValue(':userid', $this->userid);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
    }

    public function add_category(){

        if($this->isCatExist()){
            echo 'exist';
            return false;
        }
                
        $query = "INSERT INTO category (catid,catname,catdescription) 
            VALUES (:catid,:catname,:catdescription)";

        $stmt = $this->conn->prepare($query);

        $this->catid = htmlspecialchars(strip_tags($this->catid));
        $this->catname = htmlspecialchars(strip_tags($this->catname));
        $this->catdescription = htmlspecialchars(strip_tags($this->catdescription));

        $stmt->bindValue('catid', $this->catid);
        $stmt->bindValue('catname', $this->catname);
        $stmt->bindValue('catdescription', $this->catdescription);

        if($stmt->execute()){
            $this->userid = all;
            $this->title = 'New Category Created!';
            $this->body = 'A new category has been created by the Admin. Explore!';
            $this->generatedlink = "product_category.php?catid=".$this->catid;
            $this->notifications();
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function add_product(){
                
            $query = "INSERT INTO product_details (productid,userid,product_title,product_category,product_description,pack0,pack1,pack2,pack3,pack4,pack5,pack6,pack7,img0,img1,img2,img3,img4,img5,img6,status,productavailability) 
                VALUES (:productid,:userid,:product_title,:product_category,:product_description,:pack0,:pack1,:pack2,:pack3,:pack4,:pack5,:pack6,:pack7,:img0,:img1,:img2,:img3,:img4,:img5,:img6,:status,:productavailability)";

            $stmt = $this->conn->prepare($query);

            $this->productid = htmlspecialchars(strip_tags($this->productid));
            $this->userid = htmlspecialchars(strip_tags($this->userid));
            $this->product_title = htmlspecialchars(strip_tags($this->product_title));
            $this->product_category = htmlspecialchars(strip_tags($this->product_category));
            $this->product_description = htmlentities($this->product_description);
            $this->pack0 = htmlentities($this->pack0);
            $this->pack1 = htmlentities($this->pack1);
            $this->pack2 = htmlentities($this->pack2);
            $this->pack3 = htmlentities($this->pack3);
            $this->pack4 = htmlentities($this->pack4);
            $this->pack5 = htmlentities($this->pack5);
            $this->pack4 = htmlentities($this->pack6);
            $this->pack5 = htmlentities($this->pack7);
            $this->img0 = htmlspecialchars(strip_tags($this->file_name0));
            $this->img1 = htmlspecialchars(strip_tags($this->file_name1));
            $this->img2 = htmlspecialchars(strip_tags($this->file_name2));
            $this->img3 = htmlspecialchars(strip_tags($this->file_name3));
            $this->img4 = htmlspecialchars(strip_tags($this->file_name4));
            $this->img5 = htmlspecialchars(strip_tags($this->file_name5));
            $this->img6 = htmlspecialchars(strip_tags($this->file_name6));
            $this->status = htmlspecialchars(strip_tags($this->productstatus));
            $this->productavailability = htmlspecialchars(strip_tags($this->productavailability));

            $stmt->bindValue('productid', $this->productid);
            $stmt->bindValue('userid', $this->userid);
            $stmt->bindValue('product_title', $this->product_title);
            $stmt->bindValue('product_category', $this->product_category);
            $stmt->bindValue('product_description', $this->product_description);
            $stmt->bindValue('pack0', $this->pack0);
            $stmt->bindValue('pack1', $this->pack1);
            $stmt->bindValue('pack2', $this->pack2);
            $stmt->bindValue('pack3', $this->pack3);
            $stmt->bindValue('pack4', $this->pack4);
            $stmt->bindValue('pack5', $this->pack5);
            $stmt->bindValue('pack6', $this->pack6);
            $stmt->bindValue('pack7', $this->pack7);
            $stmt->bindValue('img0', $this->img0);
            $stmt->bindValue('img1', $this->img1);
            $stmt->bindValue('img2', $this->img2);
            $stmt->bindValue('img3', $this->img3);
            $stmt->bindValue('img4', $this->img4);
            $stmt->bindValue('img5', $this->img5);
            $stmt->bindValue('img6', $this->img6);
            $stmt->bindValue('status', $this->status);
            $stmt->bindValue('productavailability', $this->productavailability);

            if($stmt->execute()){
                $this->userid = $this->userid;
                $this->title = 'New Product Created!';
                $this->body = 'A new product has been created by the !'.$this->userid;
                $this->generatedlink = "product_details.php?productid=".$this->productid;
                $this->notifications();

                return true;
            }
            printf("Error: %s.\n", $stmt->error);
            return false;        
    }

    public function add_accountdetails(){

        $this->me = $this->accountdetails($this->userid);
        if($this->me > 0){
            echo 'exist';
            return false;
        }
                
        $query = "INSERT INTO accountdetails (userid,accountname,accountnumber,bankname,accounttype,status) 
            VALUES (:userid,:accountname,:accountnumber,:bankname,:accounttype,:status)";

        $stmt = $this->conn->prepare($query);

        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->bankname = htmlspecialchars(strip_tags($this->bankname));
        $this->accountnumber = htmlspecialchars(strip_tags($this->accountnumber));
        $this->accountname = htmlspecialchars(strip_tags($this->accountname));
        $this->accounttype = htmlentities($this->accounttype);
        $this->status = htmlentities($this->status);

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('accountname', $this->accountname);
        $stmt->bindValue('accountnumber', $this->accountnumber);
        $stmt->bindValue('bankname', $this->bankname);
        $stmt->bindValue('accounttype', $this->accounttype);
        $stmt->bindValue('status', $this->status);

        if($stmt->execute()){
            $this->userid = $this->userid;
            $this->title = 'Seller Added Account Details';
            $this->body = 'A seller just updated his/her account details';
            $this->generatedlink = "seller_details.php?userid=".$this->userid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function accountdetails($userid){
        $this->userid = $userid;
        $sql = "SELECT count(*) FROM `accountdetails` WHERE userid=:userid"; 
        $stmt = $this->conn->prepare($sql);

        $stmt->bindValue('userid', $userid);
        if($stmt->execute()){
            $number_of_rows = $stmt->fetchColumn(); 
            return $number_of_rows;
        }

    }

    public function acctdetails($userid){

        $stmtbiz = $this->conn->prepare("SELECT * FROM accountdetails WHERE userid=:userid");
        $stmtbiz->bindValue("userid", $userid);       
        $stmtbiz->execute();
        if($stmtbiz->rowCount() > 0){
            $data = $stmtbiz->fetch(PDO::FETCH_OBJ); //User data
            return $data;
        }else{
            return 'empty';
        }
    }

    public function user_category(){

        if($this->isUserCatExist()){
            echo 'exist';
            return false;
        }
                
        $this->t_product = 0;

        $query = "INSERT INTO user_category (catid,userid,catname_u,catdescription_u,t_product) 
            VALUES (:catid,:userid,:catname,:catdescription,:t_product)";

        $stmt = $this->conn->prepare($query);

        $this->catid = htmlspecialchars(strip_tags($this->catid));
        $this->catname = htmlspecialchars(strip_tags($this->catname));
        $this->catdescription = htmlspecialchars(strip_tags($this->catdescription));
        $this->t_product = htmlspecialchars(strip_tags($this->t_product));
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('catid', $this->catid);
        $stmt->bindValue('catname', $this->catname);
        $stmt->bindValue('catdescription', $this->catdescription);
        $stmt->bindValue('t_product', $this->t_product);
        $stmt->bindValue('userid', $this->userid);

        if($stmt->execute()){
            $userid = $this->userid;

            $this->userid = $this->userid;
            $this->title = 'A Seller Create a Catalogue' ;
            $this->body = 'A seller just created a Catalogue!';
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();
            return true;
        }else{
            printf("Error: %s.\n", $stmt->error);
            return false;  
        }
    }

    //Get Markets
    public function market_list(){
        
        $sql = 'SELECT * FROM market ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {
            echo '<li class="list-group-item">
                <div class="todo-indicator bg-info"></div>
                <div class="widget-content p-0">
                    <div class="widget-content-wrapper">
                        <div class="widget-content-left mr-3">
                            <div class="widget-content-left">
                                <img width="42" class="rounded" src="../seller/marketImage/'.$row['marketname'].'/'.$row['marketimg'].'" alt="">
                            </div>
                        </div>
                        <div class="widget-content-left">
                            <div class="widget-heading">'.$row['marketname'].' ['.$row['marketstate'].']</div>
                            <div class="widget-subheading">'.$row['marketdescription'].'</div>
                        </div>
                        <div class="widget-content-right widget-content-actions">
                            <button class="border-0 btn-transition btn btn-outline-success"><i class="fa fa-check"></i></button>
                            <button class="border-0 btn-transition btn btn-outline-danger"><i class="fa fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            </li>';
        }     
    }

    //Get Markets into dropdown list
    public function market_dropdown_list(){
        
        $sql = 'SELECT * FROM market ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {
            echo '<option value="'.$row['marketname'].'">'.$row['marketname'].'</option>';
        }     
    }

    //Get Categories
    public function category_list(){
        $sql = 'SELECT * FROM category ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {
            echo '  <li class="list-group-item">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="widget-heading">'.$row['catname'].'</div>
                                    <div class="widget-subheading mt-1 opacity-10">
                                        <div class="badge badge-sm badge-pill badge-primary">0 Products</div>
                                    </div>
                                </div>
                                <div class="widget-content-right">
                                    <div class="fsize-2 text-success">
                                        <button class="btn btn-sm btn-danger">View Details</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>';
        }     
    }

    //Get User Categories List
    public function user_category_list($userid){
        $this->userid = $userid;
        $sql = 'SELECT * FROM user_category WHERE userid='.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            $cnt = $this->user_product_count($row['userid'], $row['catname_u']);
            echo '<li class="list-group-item">
                    <div class="widget-content p-0">
                        <div class="widget-content-wrapper">
                            <div class="widget-content-left">
                                <div class="widget-heading">'.$row['catname_u'].'</div>
                                <div class="widget-subheading mt-1 opacity-10">
                                    <span class="badge badge-sm badge-pill badge-primary">'.$cnt.' Products</span>
                                </div>
                            </div>
                            <div class="widget-content-right">
                                <div class="fsize-2 text-success">
                                    <button class="btn btn-sm btn-danger"><i class="fa fa-times"></i></button>
                                    <button class="btn btn-sm btn-info">View Details</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>';
        }     
    }

    //Get User Categories List
    public function user_category_grid($userid){
        $this->userid = $userid;
        $sql = 'SELECT * FROM user_category WHERE userid='.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            $cnt = $this->user_product_count($row['userid'], $row['catname_u']);
            echo '<div>
                    <div class="slider-item">
                        <div class="card-shadow-primary card-border card">
                            <div class="dropdown-menu-header pt-5 text-center">
                                <i class="fa fa-shopping-basket fa-3x text-danger" style="color: #333333;"></i>
                            </div>
                            <div class="p-0" style="height: 120px !important;">
                                <ul class="rm-list-borders list-group list-group-flush">
                                    <li class="list-group-item">
                                        <div class="widget-content p-0 text-center">
                                            <div class="font-size-xlg text-muted">
                                                <h5 style="color: #333333;">'.$row['catname_u'].'</h5>
                                            </div>
                                            <div class="widget-heading">
                                                '.$cnt.'-products
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="text-center d-block card-footer">
                                <button class="btn btn-danger btn-sm">View all
                                </button>
                            </div>
                        </div>
                    </div>
                </div>';
        }     
    }

    public function user_product_count($userid, $catname_u){
        $sql = "SELECT count(*) FROM `product_details` WHERE userid=:userid AND product_category=:product_category"; 
        $stmt = $this->conn->prepare($sql);

        $stmt->bindValue('userid', $userid);
        $stmt->bindValue('product_category', $catname_u);
        if($stmt->execute()){
            $number_of_rows = $stmt->fetchColumn(); 
            return $number_of_rows;
            // return;
        }
    }

    public function totaluserproduct($userid){
        $sql = "SELECT count(*) FROM `product_details` WHERE userid=:userid"; 
        $stmt = $this->conn->prepare($sql);

        $stmt->bindValue('userid', $userid);
        if($stmt->execute()){
            $number_of_rows = $stmt->fetchColumn(); 
            echo $number_of_rows;
            return;
        }
    }

    //Get User product List
    public function user_product_grid($userid){
        $this->userid = $userid;
        $sql = 'SELECT * FROM product_details WHERE userid='.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            echo '<div class="col-md-12 col-lg-6 col-xl-3">
                    <div class="card-shadow-primary card-border mb-3 card">
                        <div class="dropdown-menu-header" style="width: 100%; height: 180px; overflow: hidden;">
                            <img src="productimg/'.$row['productid'].'/'.$row['img0'].'" style="width: 100% !important; height: auto !important; margin: auto;" alt="Avatar 5">
                        </div>
                        <div class="p-3">
                            <ul class="rm-list-borders list-group list-group-flush">
                                <li class="list-group-item">
                                    <div class="widget-content p-0">
                                        <div class="widget-content-wrapper">
                                            <div class="widget-content-left">
                                                <div class="widget-heading"> '. $row['product_title'] .' </div>
                                                <div class="widget-subheading">
                                                     '. $row['product_category'] .' 
                                                </div>
                                            </div>
                                            <div class="widget-content-right">
                                                <div class="font-size-sm text-muted">
                                                    <span class="badge badge-warning">'. $row['status'] .'</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="text-center d-block card-footer">
                            <button class="btn btn-warning btn-sm">View Details
                            </button>
                            <button class="btn btn-danger btn-sm">Edit Product
                            </button>
                        </div>
                    </div>
                </div>';
        }     
    }

    //Get User product Grid
    public function user_product_list($userid){
        $this->userid = $userid;

        if($this->isListExist()){
            echo '<tr>
                    <td>No record found!</td>
                </tr>';
            return true;
        }

        $sql = 'SELECT * FROM product_details WHERE userid='.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            
            if($row['status']=='Pending'){
                $butt = 'Waiting for approval!';
            }else{
                if($row['productavailability'] == 'Out of Stock'){
                    $butt = '<button class="btn btn-sm btn-outline-warning">In Stock</button>';
                }elseif($row['productavailability'] == 'In Stock'){
                    $butt = '<button class="btn btn-sm btn-outline-danger">Out of stock</button>';
                }
            }
            echo '<tr>
                    <td>'.$row['productid'].'</td>
                    <td>'.$row['product_title'].'</td>
                    <td>'.$row['product_category'].'</td>
                    <td>'.$row['productavailability'].'</td>
                    <td>'.$row['status'].'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                </tr>';
        }     
    }

    //Get Categories dropdown
    public function category_dropdown(){
        $sql = 'SELECT * FROM category ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {
            echo '<option value="'.$row['catname'].'">'.$row['catname'].'</option>';
        }     
    }

    //Get Categories dropdown
    public function category_dropdown_seller($userid){
        $this->userid = $userid;
        // $sql = 'SELECT * FROM user_category WHERE userid: ORDER BY id';
        $sql = 'SELECT * FROM user_category WHERE userid='.$this->userid;
        foreach ($this->conn->query($sql) as $row) {
            echo '<option value="'.$row['catname_u'].'">'.$row['catname_u'].'</option>';
        }     
    }

    public function upgrade_plan(){

        if($this->checkCurrentAcctType()){
            echo 'already';
            return false;
        }
                
        $query = "UPDATE account_info SET account_type=:confCode WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->plan = htmlspecialchars(strip_tags($this->plan));
        $this->durate = htmlspecialchars(strip_tags($this->durate));
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('confCode', $this->plan);
        $stmt->bindValue('userid', $this->userid);

        if($stmt->execute()){
            $userid = $this->userid;

            $this->userid = $this->userid;
            $this->title = 'Seller Account Upgraded' ;
            $this->body = 'A Seller just upgraded his/her account to: '. $this->plan;
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();
            $this->updateAcct($this->durate);
            $this->upgrade_history();
            $this->logout();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function updateAcct($durate){

        $this->durate = $durate;

        if($this->durate == 1){
            $this->start_date =  date('Y-m-d');
            $this->end_date = date('Y-m-d', strtotime($this->start_date. ' +30 days')); // Y-m-d
        }elseif($this->durate == 6){
            $this->start_date =  date('Y-m-d');
            $this->end_date = date('Y-m-d', strtotime($this->start_date. ' +180 days')); // Y-m-d
        }elseif($this->durate == 12){
            $this->start_date =  date('Y-m-d');
            $this->end_date = date('Y-m-d', strtotime($this->start_date. ' +365 days')); // Y-m-d
        }        
                
        $query = "UPDATE account_info SET account_type=:account_type, start_date=:start_date, durate=:durate, end_date=:end_date WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->plan = htmlspecialchars(strip_tags($this->plan));
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->durate = htmlspecialchars(strip_tags($this->durate));
        $this->start_date = htmlspecialchars(strip_tags($this->start_date));
        $this->end_date = htmlspecialchars(strip_tags($this->end_date));

        $stmt->bindValue('account_type', $this->plan);
        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('durate', $this->durate);
        $stmt->bindValue('start_date', $this->start_date);
        $stmt->bindValue('end_date', $this->end_date);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false;        
    }

    public function checkCurrentAcctType(){
        $query = "SELECT * FROM account_info WHERE userid=:userid AND account_type=:confCode";
        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->plan = htmlspecialchars(strip_tags($this->plan));
        $stmt->bindValue(':confCode', $this->plan);
        $stmt->bindValue(':userid', $this->userid);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
    }

    public function upgrade_history(){
        $query = "INSERT INTO upgrade_history (userid,upgradeto) 
            VALUES (:userid,:upgradeto)";

        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->plan = htmlspecialchars(strip_tags($this->plan));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('upgradeto', $this->plan);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    public function notifications(){
        $query = "INSERT INTO notifications (userid,title,body,generatedlink) 
            VALUES (:userid,:title,:body,:generatedlink)";

        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->body = htmlspecialchars(strip_tags($this->body));
        $this->generatedlink = htmlspecialchars(strip_tags($this->generatedlink));

        $stmt->bindValue('userid', $this->userid);
        $stmt->bindValue('title', $this->title);
        $stmt->bindValue('body', $this->body);
        $stmt->bindValue('generatedlink', $this->generatedlink);

        if($stmt->execute()){
            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    private function sendConfirmationEmail($email){
        $pdo = $this->conn;
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? limit 1');
        $stmt->execute([$email]);
        $code = $stmt->fetch();

        $subject = 'Confirm your registration';
        $message = 'Please confirm you registration by pasting this code in the confirmation box: ' . $code['confirm_code'];
        $headers = 'X-Mailer: PHP/' . phpversion();

        if (mail($email, $subject, $message, $headers)) {
            return true;
        } else {
            return false;
        }
    }

    public function emailActivation($userid){
        $pdo = $this->conn;
        $stmt = $pdo->prepare('UPDATE users SET status = 1 WHERE userid = ?');
        $stmt->execute([$userid]);
        if ($stmt->rowCount() > 0) {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE userid = ? and status = 1 limit 1');
            $stmt->execute([$userid]);
            $user = $stmt->fetch();

            $this->user = $user;
            session_regenerate_id();
            if (!empty($user['userid'])) {
                $_SESSION['user']['userid'] = $user['userid'];
                $_SESSION['user']['username'] = $user['username'];
                $_SESSION['user']['name'] = $user['name'];
                $_SESSION['user']['email'] = $user['email'];
                return true;
            } else {
                $this->msg = 'Account activitation failed.';
                return false;
            }
        } else {
            $this->msg = 'Account activitation failed.';
            return false;
        }
    }

    //Check if username exit;
    public function isUsernameExit(){
        $query = "SELECT * FROM users WHERE username=:username";
        $stmt = $this->conn->prepare($query);
        $this->username = htmlspecialchars(strip_tags($this->username));
        $stmt->bindValue(':username', $this->username);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    //Check if username exit;
    public function isMarketExist(){
        $query = "SELECT * FROM market WHERE marketname=:marketname AND marketstate=:marketstate";
        $stmt = $this->conn->prepare($query);
        $this->marketname = htmlspecialchars(strip_tags($this->marketname));
        $this->marketstate = htmlspecialchars(strip_tags($this->marketstate));
        $stmt->bindValue(':marketname', $this->marketname);
        $stmt->bindValue(':marketstate', $this->marketstate);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            if(is_dir( "../../seller/marketImage/".$user->marketname )){
                return true;
            }
        }
    }

    //Check if username exit;
    public function isListExist(){
        $query = "SELECT * FROM product_details WHERE userid=:userid";
        $stmt = $this->conn->prepare($query);
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $stmt->bindValue(':userid', $this->userid);
        $stmt->execute();
        if($stmt->rowCount() < 1){
                return true;
        }
    }

    public function isCatExist(){
        $query = "SELECT * FROM category WHERE catname=:catname";
        $stmt = $this->conn->prepare($query);
        $this->catname = htmlspecialchars(strip_tags($this->catname));
        $stmt->bindValue(':catname', $this->catname);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
    }

    public function isUserCatExist(){
        $query = "SELECT * FROM user_category WHERE catname_u=:catname AND userid=:userid";
        $stmt = $this->conn->prepare($query);
        $this->catname = htmlspecialchars(strip_tags($this->catname));
        $this->userid = htmlspecialchars(strip_tags($this->userid));
        $stmt->bindValue(':catname', $this->catname);
        $stmt->bindValue(':userid', $this->userid);
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
    }

    //Check if email exist
    public function isEmailExit(){
        $queryEmail = "SELECT * FROM  users WHERE email=:email";
        $stmtEmail = $this->conn->prepare($queryEmail);
        $this->email = htmlspecialchars(strip_tags($this->email));
        $stmtEmail->bindValue(':email', $this->email);
        $stmtEmail->execute();
        if($stmtEmail->rowCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    /* User Details */
    public function userDetails($userid){
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE userid=:userid");
            $stmt->bindParam("userid", $userid, PDO::PARAM_INT);
            $stmt->execute();
            $data = $stmt->fetch(PDO::FETCH_OBJ); //User data
            return $data;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    /* business Details */
    public function checkAcctType($userid){
        $stmtbiz = $this->conn->prepare("SELECT * FROM account_info WHERE userid=:userid");
        $stmtbiz->bindParam("userid", $userid, PDO::PARAM_INT);
        $stmtbiz->execute();
        $data = $stmtbiz->fetch(PDO::FETCH_OBJ); //User data
        return $data;
                // if($stmtbiz->rowCount() < 1){
        //     echo '<div class="card-body row">
        //             <div class="alert alert-danger show col-md-12" role="alert">
        //             You have to update your business information <a href="business_setting"><button class="btn btn-info btn-sm">Update business profile</button></a>
        //             </div>
        //         </div>';
        // }
    }

    public function logout(){
        $_SESSION['userid'] = null;
        session_regenerate_id();
        return true;
    }

    //Get all sellers
    public function view_all_seller(){

        $sql = 'SELECT * FROM users WHERE role != "Admin" ORDER BY sn';
        foreach ($this->conn->query($sql) as $row) {
        
            if($row['status']==1){
                $butt = '<span class="badge badge-success">Active</span>';
                $btt = '<button class="mb-2 mr-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateSeller('.$row['userid'].')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a>';
            }elseif($row['status']==0){
                $butt = '<span class="badge badge-warning">Pending</span>';
                $btt = '<button class="mb-2 mr-2 btn btn-shadow btn-outline-success btn-sm" onclick="activateSeller('.$row['userid'].')" style="float: left;"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <button class="mb-2 mr-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateSeller('.$row['userid'].')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a>';
            }elseif($row['status']==2){
                $butt = '<span class="badge badge-danger">Inactive</span>';
                $btt = '<button class="mb-2 mr-2 btn btn-shadow btn-success btn-sm" onclick="activateSeller('.$row['userid'].')"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a>';
            }
            echo '<tr>
                    <td>'.$row['userid'].'</td>
                    <td>'.$row['username'].'</td>
                    <td>'.$row['fname'].' '.$row['fname'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['phone'].'</td>
                    <td style="font-size: 13px;">'.$row['date_reg'].'</td>
                    <td>'.$butt.'</td>
                    <td>'.$btt.'</td>
                </tr>';
        }     
    }
    //Get all pending seller
    public function view_pending_seller(){

        $sql = 'SELECT * FROM users WHERE role != "Admin" AND status=0 ORDER BY sn';
        foreach ($this->conn->query($sql) as $row) {
        
            if($row['status']==1){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']==0){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']==2){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['userid'].'</td>
                    <td>'.$row['username'].'</td>
                    <td>'.$row['fname'].' '.$row['fname'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['phone'].'</td>
                    <td style="font-size: 13px;">'.$row['date_reg'].'</td>
                    <td>'.$butt.'</td>
                    <td><button class="mb-2 mr-2 btn btn-shadow btn-outline-success btn-sm" onclick="activateSeller('.$row['userid'].')" style="float: left;"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <button class="mb-2 mr-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateSeller('.$row['userid'].')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a></td>
                </tr>';
        }    
    }
    //Get all active seller
    public function view_active_seller(){

        $sql = 'SELECT * FROM users WHERE role != "Admin" AND status=1 ORDER BY sn';
        foreach ($this->conn->query($sql) as $row) {
        
            if($row['status']==1){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']==0){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']==2){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['userid'].'</td>
                    <td>'.$row['username'].'</td>
                    <td>'.$row['fname'].' '.$row['fname'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['phone'].'</td>
                    <td style="font-size: 13px;">'.$row['date_reg'].'</td>
                    <td>'.$butt.'</td>
                    <td><button class="mb-2 mr-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateSeller('.$row['userid'].')"><i class="fa fa-times btn-icon-wrapper"></i></button> <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a></td>
                </tr>';
        }  
    }
    //Get all inactive seller
    public function view_inactive_seller(){

        $sql = 'SELECT * FROM users WHERE role != "Admin" AND status=2 ORDER BY sn';
        foreach ($this->conn->query($sql) as $row) {
        
           if($row['status']==1){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']==0){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']==2){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['userid'].'</td>
                    <td>'.$row['username'].'</td>
                    <td>'.$row['fname'].' '.$row['fname'].'</td>
                    <td>'.$row['email'].'</td>
                    <td>'.$row['phone'].'</td>
                    <td style="font-size: 13px;">'.$row['date_reg'].'</td>
                    <td>'.$butt.'</td>
                    <td><button class="mb-2 mr-2 btn btn-shadow btn-outline-success btn-sm" style="float: left;" onclick="activateSeller('.$row['userid'].')"><i class="fa fa-check btn-icon-wrapper"></i></button> <a href="seller_details.php?sellerid='.$row['userid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-address-card btn-icon-wrapper"></i></a></td>
                </tr>';
        }
    }

    //Get all products
    public function view_all_products(){

        $sql = 'SELECT * FROM product_details ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {

            $userInfo = $this->userDetails($row['userid']);
        
            if($row['status']=='Active'){
                $butt = '<span class="badge badge-success">Active</span>';
                $btt = '<button class="mb-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateProduct('.$row['productid'].', '.$userInfo->userid.')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a>';
            }elseif($row['status']=="Pending"){
                $butt = '<span class="badge badge-warning">Pending</span>';
                $btt = '<button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="activateProduct('.$row['productid'].', '.$userInfo->userid.')"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <button class="mb-2 btn btn-shadow btn-danger btn-sm" onclick="deactivateProduct('.$row['productid'].', '.$userInfo->userid.')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a>';
            }elseif($row['status']=='Inactive'){
                $butt = '<span class="badge badge-danger">Inactive</span>';
                $btt = '<button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="activateProduct('.$row['productid'].', '.$userInfo->userid.')"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a>';
            }
            echo '<tr>
                    <td>'.$row['productid'].'</td>
                    <td>'.$row['product_title'].'</td>
                    <td>'.$row['product_category'].'</td>
                    <td>'.mb_substr(htmlspecialchars_decode($row['product_description']), 0, 30).'</td>
                    <td>'.$userInfo->username.'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                    <td>'.$btt.'</td>
                </tr>';
        }     
    }

    //Get all pending products
    public function view_pending_products(){

        $sql = 'SELECT * FROM product_details WHERE status="Pending" ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {

            $userInfo = $this->userDetails($row['userid']);
        
            if($row['status']=='Active'){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']=="Pending"){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']=="Inactive"){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['productid'].'</td>
                    <td>'.$row['product_title'].'</td>
                    <td>'.$row['product_category'].'</td>
                    <td>'.mb_substr(htmlspecialchars_decode($row['product_description']), 0, 30).'</td>
                    <td>'.$userInfo->username.'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                    <td>
                        <button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="deactivateProduct('.$row['productid'].')"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <button class="mb-2 btn btn-shadow btn-danger btn-sm" onclick="activateProduct('.$row['productid'].')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a></td>
                </tr>';
        }     
    }

    //Get all active products
    public function view_active_products(){

        $sql = 'SELECT * FROM product_details WHERE status="Active" ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {

            $userInfo = $this->userDetails($row['userid']);
        
            if($row['status']=='Active'){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']=="Pending"){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']=="Inactive"){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['productid'].'</td>
                    <td>'.$row['product_title'].'</td>
                    <td>'.$row['product_category'].'</td>
                    <td>'.mb_substr(htmlspecialchars_decode($row['product_description']), 0, 30).'</td>
                    <td>'.$userInfo->username.'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                    <td>
                        <button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="deactivateProduct('.$row['productid'].')">
                        <i class="fa fa-check btn-icon-wrapper"></i></button>
                        <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a>
                    </td>
                </tr>';
        }     
    }

    //Get all active products
    public function view_inactive_products(){

        $sql = 'SELECT * FROM product_details WHERE status="Inactive" ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {

            $userInfo = $this->userDetails($row['userid']);
        
            if($row['status']=='Active'){
                $butt = '<span class="badge badge-success">Active</span>';
            }elseif($row['status']=="Pending"){
                $butt = '<span class="badge badge-warning">Pending</span>';
            }elseif($row['status']=="Inactive"){
                $butt = '<span class="badge badge-danger">Inactive</span>';
            }
            echo '<tr>
                    <td>'.$row['productid'].'</td>
                    <td>'.$row['product_title'].'</td>
                    <td>'.$row['product_category'].'</td>
                    <td>'.mb_substr(htmlspecialchars_decode($row['product_description']), 0, 30).'</td>
                    <td>'.$userInfo->username.'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                    <td>
                        <button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="deactivateProduct('.$row['productid'].')">
                        <i class="fa fa-check btn-icon-wrapper"></i></button>
                        <a href="product_details.php?productid='.$row['productid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-shopping-cart btn-icon-wrapper"></i></a>
                    </td>
                </tr>';
        }     
    }

    public function activateSeller(){
        $query = "UPDATE users SET status=:status WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('status', $this->status);
        $stmt->bindValue('userid', $this->userid);

        if($stmt->execute()){
            $this->userid = $this->userid;
            $this->title = 'Account Approved' ;
            $this->body = 'Your account has been activate!';
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    public function deactivateSeller(){
        $query = "UPDATE users SET status=:status WHERE userid=:userid";

        $stmt = $this->conn->prepare($query);

        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->userid = htmlspecialchars(strip_tags($this->userid));

        $stmt->bindValue('status', $this->status);
        $stmt->bindValue('userid', $this->userid);

        if($stmt->execute()){
            $userid = $this->userid;

            $this->userid = $this->userid;
            $this->title = 'Account Disapproved' ;
            $this->body = 'Your account has been Disapproved!';
            $this->generatedlink = "seller_details.php?sellerid=".$this->userid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    public function activateProduct(){
        $query = "UPDATE product_details SET status=:status WHERE productid=:productid";

        $stmt = $this->conn->prepare($query);

        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->productid = htmlspecialchars(strip_tags($this->productid));
        $this->sellerid = htmlspecialchars(strip_tags($this->sellerid));

        $stmt->bindValue('status', $this->status);
        $stmt->bindValue('productid', $this->productid);

        if($stmt->execute()){
            $this->userid = $this->sellerid;
            $this->title = 'Product Approved' ;
            $this->body = 'Your product has been approved!';
            $this->generatedlink = "product_details.php?productid=".$this->productid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    public function deactivateProduct(){
        $query = "UPDATE product_details SET status=:status WHERE productid=:productid";

        $stmt = $this->conn->prepare($query);

        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->productid = htmlspecialchars(strip_tags($this->productid));
        $this->sellerid = htmlspecialchars(strip_tags($this->sellerid));

        $stmt->bindValue('status', $this->status);
        $stmt->bindValue('productid', $this->productid);

        if($stmt->execute()){
            $this->userid = $this->sellerid;
            $this->title = 'Product Disapproved' ;
            $this->body = 'Your product was not approved!';
            $this->generatedlink = "product_details.php?productid=".$this->productid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

    //Get all products
    public function view_all_dispute(){

        $sql = 'SELECT * FROM disputetbl ORDER BY id';
        foreach ($this->conn->query($sql) as $row) {

            $senderid = $this->userDetails($row['senderid']);
            $againstid = $this->userDetails($row['againstid']);
        
            if($row['status']=='Treated'){
                $butt = '<span class="badge badge-success">Treated</span>';
                $btt = '<a href="dispute_details.php?disputeid='.$row['disputeid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-file btn-icon-wrapper"></i></a>';
            }elseif($row['status']=="Pending"){
                $butt = '<span class="badge badge-warning">Pending</span>';
                $btt = '<button class="mb-2 btn btn-shadow btn-outline-success btn-sm" onclick="resolvedDispute('.$row['disputeid'].', '.$senderid->userid.', '.$againstid->userid.')"><i class="fa fa-check btn-icon-wrapper"></i></button>
                        <button class="mb-2 btn btn-shadow btn-danger btn-sm" onclick="cancelledDispute('.$row['disputeid'].', '.$senderid->userid.', '.$againstid->userid.')"><i class="fa fa-times btn-icon-wrapper"></i></button>
                        <a href="dispute_details.php?disputeid='.$row['disputeid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-file btn-icon-wrapper"></i></a>';
            }elseif($row['status']=='Cancelled'){
                $butt = '<span class="badge badge-danger">Cancelled</span>';
                $btt = '<a href="dispute_details.php?disputeid='.$row['disputeid'].'" class="mb-2 btn btn-shadow btn-info btn-sm"><i class="fa fa-file btn-icon-wrapper"></i></a>';
            }
            echo '<tr>
                    <td>'.$row['disputeid'].'</td>
                    <td>'.$senderid->username.'<button type="button" class="btn btn-shadow btn-outline-info btn-sm" onclick="replySender('.$row['disputeid'].', '.$row['senderid'].', '.$row['againstid'].', this.id)" id="'.$senderid->username.'-'.$againstid->username.'"> <i class="fa fa-reply"></i></button></td>
                    <td>'.$againstid->username.'<button type="button" class="btn btn-shadow btn-outline-info btn-sm" onclick="replyAgainst('.$row['disputeid'].', '.$row['senderid'].', '.$row['againstid'].', this.id)" id="'.$senderid->username.'-'.$againstid->username.'"> <i class="fa fa-reply"></i></button></td>
                    <td>'.$row['subject'].'</td>
                    <td>'.$row['priority'].'</td>
                    <td>'.$row['created_at'].'</td>
                    <td>'.$butt.'</td>
                    <td>'.$btt.'</td>
                </tr>';
        }     
    }

    public function processDispute(){
        $query = "UPDATE product_details SET status=:status WHERE productid=:productid";

        $stmt = $this->conn->prepare($query);

        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->productid = htmlspecialchars(strip_tags($this->productid));
        $this->sellerid = htmlspecialchars(strip_tags($this->sellerid));

        $stmt->bindValue('status', $this->status);
        $stmt->bindValue('productid', $this->productid);

        if($stmt->execute()){
            $this->userid = $this->sellerid;
            $this->title = 'Product Disapproved' ;
            $this->body = 'Your product was not approved!';
            $this->generatedlink = "product_details.php?productid=".$this->productid;
            $this->notifications();

            return true;
        }
        printf("Error: %s.\n", $stmt->error);
        return false; 
    }

}