<?php
//show error reporting
error_reporting(E_ALL);

//set your default time-zone
date_default_timezone_set('Africa/Lagos');
