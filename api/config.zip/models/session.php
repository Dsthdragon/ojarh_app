<?php
	if(isset($_SESSION['userid']) || !empty($_SESSION['userid']))
	{
		$userid=$_SESSION['userid'];
		$userrole=$_SESSION['role'];
		include_once('all.php');
		$db = getDB();
		$userClass = new Users($db);
		if($userrole=='Admin'){
			$userDetails = $userClass->userDetails($userid);
			$bizdata = $userClass->bizDetails($userid);
			$acctdetails = $userClass->acctdetails($userid);
			$acctType = $userClass->checkAcctType($userid);
			// $userAcctType = $acctType->account_type;
			// $userAcctenddate = $acctType->end_date;
		}elseif($userrole=='Seller'){
			$userDetails = $userClass->userDetails($userid);
			$bizdata = $userClass->bizDetails($userid);
			$acctdetails = $userClass->acctdetails($userid);
			$acctType = $userClass->checkAcctType($userid);
			$userAcctType = $acctType->account_type;
			$userAcctenddate = $acctType->end_date;
		}elseif ($userrole=='Admin') {
			$userDetails = $userClass->userDetails($userid);
			$bizdata = $userClass->bizDetails($userid);
			$acctdetails = $userClass->acctdetails($userid);
			$acctType = $userClass->checkAcctType($userid);
			$userAcctType = $acctType->account_type;
			$userAcctenddate = $acctType->end_date;
		}
		
	}else{
		session_destroy();
		session_unset();
		header("Location: " . BASE_URL);
	}
?>